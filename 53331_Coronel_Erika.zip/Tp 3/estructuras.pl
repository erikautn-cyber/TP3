% EJERCICIO 21
% Cada nodo es una estructura persona(Nombre, DNI, Edad).

nodo(persona(r, 10000001, 80)).
nodo(persona(a, 10000002, 55)).
nodo(persona(b, 10000003, 52)).
nodo(persona(c, 10000004, 48)).
nodo(persona(d, 10000005, 30)).
nodo(persona(e, 10000006, 28)).
nodo(persona(f, 10000007, 27)).
nodo(persona(g, 10000008, 25)).
nodo(persona(h, 10000009, 8)).
nodo(persona(i, 10000010, 7)).
nodo(persona(j, 10000011, 5)).
nodo(persona(k, 10000012, 3)).

% Relaciones del arbol del enunciado.

enlace(r, a).
enlace(r, b).
enlace(r, c).
enlace(a, d).
enlace(a, e).
enlace(b, f).
enlace(b, g).
enlace(e, h).
enlace(f, i).
enlace(f, j).
enlace(g, k).

hijo(Padre, Hijo) :-
    nodo(Padre),
    nodo(Hijo),
    Padre = persona(NombrePadre, _, _),
    Hijo = persona(NombreHijo, _, _),
    enlace(NombrePadre, NombreHijo).

descendiente(Ancestro, Descendiente) :-
    hijo(Ancestro, Descendiente).
descendiente(Ancestro, Descendiente) :-
    hijo(Ancestro, Intermedio),
    descendiente(Intermedio, Descendiente).

ascendiente(Nodo, Ancestro) :-
    descendiente(Ancestro, Nodo).

mostrar_descendientes(Nombre) :-
    nodo(Nodo),
    Nodo = persona(Nombre, _, _),
    descendiente(Nodo, Descendiente),
    write(Descendiente),
    nl,
    fail.
mostrar_descendientes(Nombre) :-
    nodo(persona(Nombre, _, _)).

mostrar_ascendientes(Nombre) :-
    nodo(Nodo),
    Nodo = persona(Nombre, _, _),
    ascendiente(Nodo, Ancestro),
    write(Ancestro),
    nl,
    fail.
mostrar_ascendientes(Nombre) :-
    nodo(persona(Nombre, _, _)).


% EJERCICIO 22
% Falla si las listas tienen distintas longitudes.

parejas([], [], []).
parejas([C1|Q1], [C2|Q2], [(C1, C2)|R]) :-
    parejas(Q1, Q2, R).


% EJERCICIO 23
% Sexo: m = mujer; v = varon.
% Telefonos ficticios guardados como atomos.

persona(ana, '2611111111', m, 25).
persona(luis, '2612222222', v, 30).
persona(maria, '2613333333', m, 22).
persona(pedro, '2614444444', v, 20).
persona(carla, '2615555555', m, 35).
persona(juan, '2616666666', v, 40).

% Version de tres argumentos para la regla final del enunciado.

persona(Nombre, Telefono, Sexo) :-
    persona(Nombre, Telefono, Sexo, _).

existe(Nombre) :-
    persona(Nombre, _, _, _).

mostrar_personas :-
    persona(Nombre, Telefono, Sexo, Edad),
    write(persona(Nombre, Telefono, Sexo, Edad)),
    nl,
    fail.
mostrar_personas.

mostrar_mujeres :-
    persona(Nombre, Telefono, m, Edad),
    write(persona(Nombre, Telefono, m, Edad)),
    nl,
    fail.
mostrar_mujeres.

mostrar_varones_mayores21 :-
    persona(Nombre, Telefono, v, Edad),
    Edad > 21,
    write(persona(Nombre, Telefono, v, Edad)),
    nl,
    fail.
mostrar_varones_mayores21.

% Matrimonios identificados mediante los telefonos.

matrimonio('2611111111', '2612222222').
matrimonio('2615555555', '2616666666').

casado(T1, T2) :-
    matrimonio(T1, T2).
casado(T1, T2) :-
    matrimonio(T2, T1).

% Visitas identificadas mediante los telefonos.

visita('2612222222', maria).
visita('2616666666', ana).
visita('2614444444', luis).

mostrar_casados :-
    matrimonio(T1, T2),
    persona(Nombre1, T1, _, _),
    persona(Nombre2, T2, _, _),
    write(Nombre1),
    write(' esta casado/a con '),
    write(Nombre2),
    nl,
    fail.
mostrar_casados.

% X es el telefono de alguien cuya pareja visita a una mujer.

c(X) :-
    casado(X, Y),
    visita(Y, Z),
    persona(Z, _, m).

% Las visitas usan telefonos, pero persona/3 espera un nombre
% en su primer argumento. Se agrega esta conversion.

% EJERCICIO 24
% Aristas dirigidas: se respetan las flechas del dibujo.

arista(mendoza, san_juan, 160).
arista(mendoza, san_luis, 280).
arista(san_juan, cordoba, 480).
arista(san_luis, buenos_aires, 710).
arista(cordoba, san_luis, 350).
arista(cordoba, buenos_aires, 540).
arista(cordoba, misiones, 950).
arista(cordoba, santa_fe, 280).
arista(misiones, santa_fe, 570).

ciudad(mendoza).
ciudad(san_juan).
ciudad(san_luis).
ciudad(cordoba).
ciudad(buenos_aires).
ciudad(misiones).
ciudad(santa_fe).

visitada(C, [C|_]).
visitada(C, [_|Q]) :-
    visitada(C, Q).

% Camino y distancia total de ese recorrido.

camino(Origen, Destino, Recorrido, Distancia) :-
    ciudad(Origen),
    ciudad(Destino),
    buscar_camino(Origen, Destino, [Origen], Recorrido, Distancia).

buscar_camino(C, C, _, [C], 0).
buscar_camino(Origen, Destino, Visitadas, [Origen|R], D) :-
    Origen \= Destino,
    arista(Origen, Siguiente, Tramo),
    \+ visitada(Siguiente, Visitadas),
    buscar_camino(
        Siguiente,
        Destino,
        [Siguiente|Visitadas],
        R,
        Parcial
    ),
    D is Tramo + Parcial.

existe_camino(Origen, Destino) :-
    camino(Origen, Destino, _, _).

distancia(Origen, Destino, D) :-
    camino(Origen, Destino, _, D).

mostrar_camino(Origen, Destino) :-
    camino(Origen, Destino, Recorrido, D),
    escribir_recorrido(Recorrido),
    write('Distancia total: '),
    write(D),
    write(' km'),
    nl.

escribir_recorrido([]).
escribir_recorrido([C|Q]) :-
    write(C),
    nl,
    escribir_recorrido(Q).