% AUXILIARES

concatenar([], L, L).
concatenar([C|Q], L, [C|R]) :-
    concatenar(Q, L, R).

pertenece(E, [E|_]).
pertenece(E, [_|Q]) :-
    pertenece(E, Q).


% EJERCICIO 7

predecesor([], []).
predecesor([C|Q], [C|R]) :-
    filtrar_predecesor(Q, C, R).

filtrar_predecesor([], _, []).
filtrar_predecesor([C|Q], Anterior, [C|R]) :-
    C >= Anterior,
    filtrar_predecesor(Q, C, R).
filtrar_predecesor([C|Q], Anterior, R) :-
    C < Anterior,
    filtrar_predecesor(Q, C, R).


% EJERCICIO 8
% Permite rotar mas posiciones que la longitud de la lista.

rotada(L, N, R) :-
    integer(N),
    N >= 0,
    rotar_pasos(L, N, R).

rotar_pasos(L, 0, L).
rotar_pasos([], N, []) :-
    N > 0.
rotar_pasos([C|Q], N, R) :-
    N > 0,
    concatenar(Q, [C], Nueva),
    Anterior is N - 1,
    rotar_pasos(Nueva, Anterior, R).


% EJERCICIO 9

suma(0, []).
suma(S, [C|Q]) :-
    suma(Parcial, Q),
    S is C + Parcial.


% EJERCICIO 10

cantidad([], 0).
cantidad([_|Q], N) :-
    cantidad(Q, Parcial),
    N is Parcial + 1.


% EJERCICIO 11

ultimo([U], U).
ultimo([_, C|Q], U) :-
    ultimo([C|Q], U).


% EJERCICIO 12

inversa([], []).
inversa([C|Q], I) :-
    inversa(Q, Parcial),
    concatenar(Parcial, [C], I).


% EJERCICIO 13
% Falla si la posicion no existe.

sacar(1, [_|Q], Q).
sacar(P, [C|Q], [C|R]) :-
    integer(P),
    P > 1,
    Anterior is P - 1,
    sacar(Anterior, Q, R).


% EJERCICIO 15
% Elimina todas las apariciones de E.

eliminar([], _, []).
eliminar([E|Q], E, R) :-
    eliminar(Q, E, R).
eliminar([C|Q], E, [C|R]) :-
    C \= E,
    eliminar(Q, E, R).


% EJERCICIO 16
% Interseccion sin elementos repetidos.

intersec([], _, []).
intersec([C|Q], L2, [C|R]) :-
    pertenece(C, L2),
    !,
    eliminar(Q, C, SinRepetidos),
    intersec(SinRepetidos, L2, R).
intersec([_|Q], L2, R) :-
    intersec(Q, L2, R).


% EJERCICIO 17
% La consigna repite la rotacion del ejercicio 8.

rotarIzq(L, N, R) :-
    rotada(L, N, R).


% EJERCICIO 18
% Se puede insertar al principio, en el medio o al final.

insertarEn(E, L, 1, [E|L]).
insertarEn(E, [C|Q], P, [C|R]) :-
    integer(P),
    P > 1,
    Anterior is P - 1,
    insertarEn(E, Q, Anterior, R).


% EJERCICIO 19
% La lista de entrada debe estar ordenada de menor a mayor.

insOrden(E, [], [E]).
insOrden(E, [C|Q], [E, C|Q]) :-
    E =< C.
insOrden(E, [C|Q], [C|R]) :-
    E > C,
    insOrden(E, Q, R).


% EJERCICIO 20

ordenada([], []).
ordenada([C|Q], O) :-
    ordenada(Q, Parcial),
    insOrden(C, Parcial, O).