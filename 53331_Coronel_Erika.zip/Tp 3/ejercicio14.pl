% EJERCICIO 14
% Elimina una sola aparicion del elemento.

eliminar([], _, []).
eliminar([E|Q], E, Q) :-
    !.
eliminar([C|Q], E, [C|R]) :-
    eliminar(Q, E, R).