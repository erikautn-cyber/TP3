% EJERCICIO 1
% Determina si un entero es par, sin usar mod.

par(N) :-
    integer(N),
    A is abs(N),
    par_positivo(A).

par_positivo(0).
par_positivo(N) :-
    N >= 2,
    Anterior is N - 2,
    par_positivo(Anterior).


% EJERCICIO 2
% Suma los primeros N numeros naturales pares positivos.

suma(0, 0).
suma(N, S) :-
    integer(N),
    N > 0,
    Anterior is N - 1,
    suma(Anterior, Parcial),
    S is Parcial + 2 * N.


% EJERCICIO 3
% Potencia con exponente entero no negativo.

potencia(_, 0, 1).
potencia(B, E, V) :-
    integer(E),
    E > 0,
    Anterior is E - 1,
    potencia(B, Anterior, Parcial),
    V is B * Parcial.


% EJERCICIO 4

fibonacci(0, 0).
fibonacci(1, 1).
fibonacci(N, R) :-
    integer(N),
    N > 1,
    N1 is N - 1,
    N2 is N - 2,
    fibonacci(N1, R1),
    fibonacci(N2, R2),
    R is R1 + R2.


% EJERCICIO 5
% Tablas de verdad de las compuertas.

and(0, 0, 0).
and(0, 1, 0).
and(1, 0, 0).
and(1, 1, 1).

or(0, 0, 0).
or(0, 1, 1).
or(1, 0, 1).
or(1, 1, 1).

not(0, 1).
not(1, 0).

% Circuito del enunciado:
% S = (NOT Q1 AND Q2) OR (Q1 AND NOT Q2).

circuito(Q1, Q2, S) :-
    not(Q1, Negado1),
    not(Q2, Negado2),
    and(Negado1, Q2, Salida1),
    and(Q1, Negado2, Salida2),
    or(Salida1, Salida2, S).


% EJERCICIO 6
% Datos ficticios para practicar el predicado.

sintoma(ana, fiebre).
sintoma(ana, tos).
sintoma(luis, estornudos).
sintoma(luis, congestion).
sintoma(maria, dolor_de_cabeza).

enfermedad(gripe, fiebre).
enfermedad(gripe, tos).
enfermedad(resfrio, estornudos).
enfermedad(resfrio, congestion).
enfermedad(migrania, dolor_de_cabeza).

diagnostico(P, S, E) :-
    sintoma(P, S),
    enfermedad(E, S).